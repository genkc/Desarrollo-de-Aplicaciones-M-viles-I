package com.example.banco_movil
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.util.Calendar

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_register)

        val txtSaludoRegistro =
            findViewById<TextView>(R.id.txtSaludoregistro)

        val horaActual =
            Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

        if (horaActual < 12) {
            txtSaludoRegistro.text =
                getString(R.string.buenos_dias)
        } else if (horaActual < 19) {
            txtSaludoRegistro.text =
                getString(R.string.buenas_tardes)
        } else {
            txtSaludoRegistro.text =
                getString(R.string.buenas_noches)
        }

        val editTextDate =
            findViewById<EditText>(R.id.editTextDate)

        editTextDate.setOnClickListener {
            mostrarCalendario(editTextDate)
        }

        val etCorreo =
            findViewById<TextInputEditText>(R.id.etCorreo)

        val etContrasena =
            findViewById<TextInputEditText>(R.id.etContrasena)

        val etConfirmarContrasena =
            findViewById<TextInputEditText>(R.id.etConfirmarContrasena)

        val tilContrasena =
            findViewById<TextInputLayout>(R.id.tilContrasena)

        val tilConfirmarContrasena =
            findViewById<TextInputLayout>(R.id.tilConfirmarContrasena)

        fun validarCoincidenciaPasswords() {

            val password =
                etContrasena.text.toString()

            val confirmPassword =
                etConfirmarContrasena.text.toString()

            if (
                confirmPassword.isEmpty()
            ) {

                tilContrasena.boxStrokeColor =
                    Color.parseColor("#6200EE")

                tilConfirmarContrasena.boxStrokeColor =
                    Color.parseColor("#6200EE")

            } else if (
                password == confirmPassword
            ) {

                tilContrasena.boxStrokeColor =
                    Color.parseColor("#4CAF50")

                tilConfirmarContrasena.boxStrokeColor =
                    Color.parseColor("#4CAF50")

            } else {

                tilContrasena.boxStrokeColor =
                    Color.parseColor("#6200EE")

                tilConfirmarContrasena.boxStrokeColor =
                    Color.parseColor("#F44336")

            }

        }
        etContrasena.addTextChangedListener(
            object : TextWatcher {

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {

                    validarCoincidenciaPasswords()

                }

                override fun afterTextChanged(
                    s: Editable?
                ) {
                }
            }
        )

        etConfirmarContrasena.addTextChangedListener(
            object : TextWatcher {

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int
                ) {

                    validarCoincidenciaPasswords()

                }

                override fun afterTextChanged(
                    s: Editable?
                ) {
                }
            }
        )

        val btnRegistrarse =
            findViewById<Button>(R.id.btnRegistrarse)

        val txtIniciarSesion =
            findViewById<TextView>(R.id.txtIniciarSesion)

        btnRegistrarse.setOnClickListener {

            val correo =
                etCorreo.text.toString().trim()

            val password =
                etContrasena.text.toString().trim()

            val confirmPassword =
                etConfirmarContrasena.text.toString().trim()

            if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {

                AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage(
                        "El usuario debe tener formato de correo electrónico válido."
                    )
                    .setPositiveButton(
                        "Aceptar",
                        null
                    )
                    .show()

                return@setOnClickListener
            }

            val passwordRegex =
                Regex(
                    "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&._#-]).+$"
                )

            if (!passwordRegex.matches(password)) {

                AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage(
                        "La contraseña debe contener:\n\n" +
                                "• Una mayúscula\n" +
                                "• Una minúscula\n" +
                                "• Un número\n" +
                                "• Un carácter especial"
                    )
                    .setPositiveButton(
                        "Aceptar",
                        null
                    )
                    .show()

                return@setOnClickListener
            }

            if (password != confirmPassword) {

                AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage(
                        "Las contraseñas no coinciden."
                    )
                    .setPositiveButton(
                        "Aceptar",
                        null
                    )
                    .show()

                return@setOnClickListener
            }

            AlertDialog.Builder(this)
                .setTitle("Bienvenido a Banco Móvil")
                .setMessage(
                    "Usuario registrado exitosamente."
                )
                .setPositiveButton(
                    "Aceptar",
                    null
                )
                .show()
        }

        txtIniciarSesion.setOnClickListener {

            val intent = Intent(
                this,
                LoginActivity::class.java
            )

            startActivity(intent)

            finish()
        }
    }

    @SuppressLint("DefaultLocale")
    private fun mostrarCalendario(
        editText: EditText
    ) {

        val calendario =
            Calendar.getInstance()

        val anioActual =
            calendario.get(Calendar.YEAR)

        val mesActual =
            calendario.get(Calendar.MONTH)

        val diaActual =
            calendario.get(Calendar.DAY_OF_MONTH)

        val datePicker =
            DatePickerDialog(
                this,
                { _, anioSeleccionado, mesSeleccionado, diaSeleccionado ->

                    val dia =
                        String.format(
                            "%02d",
                            diaSeleccionado
                        )

                    val mes =
                        String.format(
                            "%02d",
                            mesSeleccionado + 1
                        )

                    val fechaFormateada =
                        "$dia/$mes/$anioSeleccionado"

                    editText.setText(
                        fechaFormateada
                    )

                },
                anioActual,
                mesActual,
                diaActual
            )

        datePicker.datePicker.maxDate =
            System.currentTimeMillis()

        datePicker.show()
    }
}