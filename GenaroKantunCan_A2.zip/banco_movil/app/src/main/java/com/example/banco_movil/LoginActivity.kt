package com.example.banco_movil
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import java.util.Calendar

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContentView(R.layout.activity_login)

        val txtSaludo = findViewById<TextView>(R.id.txtSaludo)
        val edtCorreo = findViewById<TextInputEditText>(R.id.edtCorreo)
        val btnIngresar = findViewById<Button>(R.id.btnIngresar)
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)

        val horaActual = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

        if (horaActual < 12) {
            txtSaludo.text = "Buenos días"
        } else if (horaActual < 19) {
            txtSaludo.text = "Buenas tardes"
        } else {
            txtSaludo.text = "Buenas noches"
        }

        btnIngresar.setOnClickListener {

            val correo = edtCorreo.text.toString().trim()
            val edtPassword =
                findViewById<TextInputEditText>(R.id.edtPassword)
            val password = edtPassword.text.toString().trim()

            if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {

                AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage(
                        "El usuario debe tener formato de correo electrónico."
                    )
                    .setPositiveButton("Aceptar", null)
                    .show()

                return@setOnClickListener
            }

            if (
                correo == "admin@bancomovil.com" &&
                password == "Admin#1"
            ) {

                AlertDialog.Builder(this)
                    .setTitle("Bienvenido a Banco Móvil")
                    .setMessage("Acceso concedido.")
                    .setPositiveButton("Aceptar", null)
                    .show()

            } else {

                AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage("Usuario o contraseña incorrectos.")
                    .setPositiveButton("Aceptar", null)
                    .show()

            }

        }

        btnRegistrar.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
